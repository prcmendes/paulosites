
import { GoogleGenAI } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIRecommendation = async (userQuery: string, currentProducts: Product[]) => {
  try {
    const productContext = JSON.stringify(currentProducts.map(p => ({
      title: p.title,
      id: p.id,
      description: p.description
    })));

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `O usuário perguntou: "${userQuery}". Com base nos seguintes produtos: ${productContext}, recomende o melhor e explique brevemente o porquê em tom de vendas amigável.`,
      config: {
        systemInstruction: "Você é um assistente de vendas especialista em produtos digitais. Seja conciso e persuasivo em português do Brasil."
      }
    });

    return response.text || "Desculpe, não consegui processar sua recomendação agora.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Estou tendo dificuldades para acessar minha base de dados.";
  }
};
