
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import AIScout from './components/AIScout';
import AdminDashboard from './components/AdminDashboard';
import Login from './components/Login';
import { PRODUCTS as INITIAL_PRODUCTS } from './constants';
import { Product } from './types';

const ADMIN_PASSWORD = "admin"; // VOCÊ PODE ALTERAR ESTA SENHA AQUI

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Estado dinâmico dos produtos
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('marketmaster_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // Persistência automática
  useEffect(() => {
    localStorage.setItem('marketmaster_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  const handleSaveProduct = (updatedProduct: Product) => {
    setProducts(prev => {
      const exists = prev.find(p => p.id === updatedProduct.id);
      if (exists) {
        return prev.map(p => p.id === updatedProduct.id ? updatedProduct : p);
      }
      return [...prev, updatedProduct];
    });
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleLogin = (password: string) => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setCurrentPage('admin');
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage('home');
  };

  const renderHome = () => (
    <div className="space-y-20">
      <section className="relative py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 tracking-tight mb-6">
              Acelere sua Jornada <span className="text-blue-600">Digital</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-600 mb-10 leading-relaxed">
              Descubra ebooks, cursos e ferramentas validadas para transformar sua presença online.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button onClick={() => setCurrentPage('shop')} className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-200">Explorar Catálogo</button>
              <button onClick={() => setCurrentPage('admin')} className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all">Painel Admin</button>
            </div>
          </div>
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-0 opacity-10 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-400 blur-[120px] rounded-full"></div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Destaques da Semana</h2>
          </div>
          <button onClick={() => setCurrentPage('shop')} className="text-blue-600 font-bold flex items-center gap-1 hover:gap-2 transition-all">Ver todos →</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.slice(0, 3).map(product => (
            <ProductCard key={product.id} product={product} onSelect={(p) => { setSelectedProduct(p); setCurrentPage('detail'); }} />
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <AIScout products={products} />
      </section>
    </div>
  );

  const renderShop = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Catálogo Completo</h1>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {products.map(product => (
          <ProductCard key={product.id} product={product} onSelect={(p) => { setSelectedProduct(p); setCurrentPage('detail'); }} />
        ))}
      </div>
    </div>
  );

  const renderProductDetail = () => {
    if (!selectedProduct) return renderShop();
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <button onClick={() => setCurrentPage('shop')} className="flex items-center gap-2 text-slate-500 hover:text-blue-600 transition-colors mb-8 group">← Voltar</button>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <img src={selectedProduct.imageUrl} alt={selectedProduct.title} className="rounded-3xl shadow-2xl w-full h-[500px] object-cover" />
          <div className="flex flex-col justify-center">
            <span className="text-blue-600 font-bold uppercase tracking-widest text-sm mb-4">{selectedProduct.category}</span>
            <h1 className="text-4xl font-bold mb-6">{selectedProduct.title}</h1>
            <p className="text-xl text-slate-600 mb-8">{selectedProduct.description}</p>
            <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100 flex items-center justify-between">
              <span className="text-3xl font-bold">R$ {selectedProduct.price.toFixed(2)}</span>
              <a href={selectedProduct.affiliateLink || '#'} target="_blank" className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold shadow-xl shadow-blue-200">Comprar Agora</a>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const getContent = () => {
    switch (currentPage) {
      case 'home': return renderHome();
      case 'shop': return renderShop();
      case 'admin': 
        return isAuthenticated ? (
          <div className="space-y-4">
             <div className="max-w-6xl mx-auto px-6 pt-8 flex justify-end">
                <button onClick={handleLogout} className="text-red-500 hover:text-red-700 text-sm font-bold flex items-center gap-1">
                  Sair do Painel <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                </button>
             </div>
             <AdminDashboard products={products} onSave={handleSaveProduct} onDelete={handleDeleteProduct} />
          </div>
        ) : (
          <Login onLogin={handleLogin} />
        );
      case 'about': return <div className="py-20 text-center"><h1>Sobre Nós</h1></div>;
      case 'contact': return <div className="py-20 text-center"><h1>Contato</h1></div>;
      case 'detail': return renderProductDetail();
      case 'privacy': return <div className="py-20 max-w-4xl mx-auto px-4"><h1>Privacidade</h1></div>;
      case 'terms': return <div className="py-20 max-w-4xl mx-auto px-4"><h1>Termos</h1></div>;
      default: return renderHome();
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      <main className="flex-grow">
        {getContent()}
      </main>
      <Footer onNavigate={setCurrentPage} />
    </div>
  );
};

export default App;
