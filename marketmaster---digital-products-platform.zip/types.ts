
export enum Category {
  EBOOK = 'Ebook',
  COURSE = 'Curso',
  AFFILIATE = 'Afiliado',
  TOOLS = 'Ferramentas'
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category: Category;
  imageUrl: string;
  affiliateLink?: string;
  features: string[];
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}
