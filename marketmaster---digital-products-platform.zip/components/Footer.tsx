
import React from 'react';

interface FooterProps {
    onNavigate: (page: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">M</div>
              <span className="text-white font-bold text-lg">MarketMaster</span>
            </div>
            <p className="text-sm leading-relaxed max-w-sm">
              Sua plataforma de confiança para adquirir conhecimentos transformadores e ferramentas digitais de alta performance. 
              Transformamos sonhos em resultados tangíveis.
            </p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Links Úteis</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => onNavigate('shop')} className="hover:text-white transition-colors">Produtos</button></li>
              <li><button onClick={() => onNavigate('about')} className="hover:text-white transition-colors">Sobre Nós</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-white transition-colors">Contato</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => onNavigate('privacy')} className="hover:text-white transition-colors">Privacidade</button></li>
              <li><button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">Termos de Uso</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-white transition-colors">Suporte</button></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-xs">
          <p>© {new Date().getFullYear()} MarketMaster Digital Solutions. Todos os direitos reservados.</p>
          <p className="mt-2 text-slate-600 italic">"O sucesso é a soma de pequenos esforços repetidos dia após dia."</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
