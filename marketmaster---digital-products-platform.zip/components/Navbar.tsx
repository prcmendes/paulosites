
import React from 'react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPage }) => {
  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">M</div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
              MarketMaster
            </span>
          </div>
          <div className="hidden md:flex space-x-8">
            {['home', 'shop', 'admin', 'about', 'contact'].map((page) => (
              <button
                key={page}
                onClick={() => onNavigate(page)}
                className={`text-sm font-medium capitalize transition-colors ${
                  currentPage === page ? 'text-blue-600' : 'text-slate-600 hover:text-blue-500'
                }`}
              >
                {page === 'home' ? 'Início' : page === 'shop' ? 'Produtos' : page === 'admin' ? 'Painel' : page === 'about' ? 'Sobre' : 'Contato'}
              </button>
            ))}
          </div>
          <button 
            onClick={() => onNavigate('shop')}
            className="bg-blue-600 text-white px-5 py-2 rounded-full text-sm font-semibold hover:bg-blue-700 transition-all shadow-md shadow-blue-200"
          >
            Ver Ofertas
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
