
import React, { useState } from 'react';
import { getAIRecommendation } from '../services/geminiService';
import { Product } from '../types';

interface AIScoutProps {
  products: Product[];
}

const AIScout: React.FC<AIScoutProps> = ({ products }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    const result = await getAIRecommendation(query, products);
    setResponse(result);
    setLoading(false);
  };

  return (
    <div className="bg-indigo-900 rounded-3xl p-8 text-white relative overflow-hidden shadow-2xl shadow-indigo-200">
      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/20 blur-3xl -mr-16 -mt-16 rounded-full"></div>
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <h3 className="text-xl font-bold">Assistente Inteligente</h3>
            <p className="text-indigo-200 text-xs">O que você está buscando hoje?</p>
          </div>
        </div>

        <div className="flex gap-2">
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Ex: 'Quero vender mais no Instagram'"
            className="flex-grow bg-indigo-800/50 border border-indigo-700 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 placeholder-indigo-400"
          />
          <button 
            onClick={handleSearch}
            disabled={loading}
            className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors disabled:opacity-50"
          >
            {loading ? '...' : 'Enviar'}
          </button>
        </div>

        {response && (
          <div className="mt-6 p-4 bg-white/10 rounded-xl border border-white/5 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <p className="text-sm leading-relaxed italic">
              "{response}"
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIScout;
