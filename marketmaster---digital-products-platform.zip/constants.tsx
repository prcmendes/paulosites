
import { Product, Category } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Guia Definitivo do Marketing Digital 2024',
    description: 'Aprenda as estratégias que realmente funcionam no cenário atual do marketing digital. De tráfego pago a SEO.',
    price: 47.90,
    category: Category.EBOOK,
    imageUrl: 'https://picsum.photos/seed/ebook1/600/400',
    features: ['Acesso vitalício', 'PDF Interativo', 'Checklist de implementação']
  },
  {
    id: '2',
    title: 'Mentoria Express: Vendas no Instagram',
    description: 'Transforme seu perfil em uma máquina de vendas com técnicas de copywriting e design persuasivo.',
    price: 97.00,
    category: Category.COURSE,
    imageUrl: 'https://picsum.photos/seed/course1/600/400',
    features: ['10 Módulos em vídeo', 'Templates de artes', 'Suporte VIP']
  },
  {
    id: '3',
    title: 'Planner de Produtividade Máxima',
    description: 'O segredo dos grandes empreendedores para gerir o tempo e bater metas mensais de forma consistente.',
    price: 29.90,
    category: Category.TOOLS,
    imageUrl: 'https://picsum.photos/seed/tool1/600/400',
    features: ['Imprimível', 'Versão Digital para Notion', 'Guia de uso']
  },
  {
    id: '4',
    title: 'Ferramenta de Automação de WhatsApp',
    description: 'Escalabilidade para seu atendimento. Produto recomendado com excelentes taxas de conversão.',
    price: 147.00,
    category: Category.AFFILIATE,
    imageUrl: 'https://picsum.photos/seed/aff1/600/400',
    affiliateLink: 'https://hotmart.com/example',
    features: ['Multi-dispositivos', 'Agendamento de mensagens', 'Garantia de 7 dias']
  }
];
